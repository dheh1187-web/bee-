import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { DM_Sans, Space_Grotesk } from 'next/font/google'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { BeePreloader } from '@/components/bee-preloader'
import './globals.css'

const dmSans = DM_Sans({
  subsets: ['latin', 'cyrillic-ext'],
  variable: '--font-body',
})

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-heading',
})

export const metadata: Metadata = {
  title: 'BeeValues — ценности предметов Roblox Jailbreak',
  description:
    'BeeValues — улей ценностей Jailbreak: актуальные цены предметов, проверка инвентаря игроков и калькулятор трейдов. Машины, хайперхромы, текстуры и всё остальное.',
  generator: 'v0.app',
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#0a0a0a',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html
      lang="ru"
      className={`dark bg-background ${dmSans.variable} ${spaceGrotesk.variable}`}
    >
      <body className="antialiased">
        <BeePreloader />
        <SiteHeader />
        <main className="min-h-screen pt-24">{children}</main>
        <SiteFooter />
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
