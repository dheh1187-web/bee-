import Link from 'next/link'
import { BeeLogo } from './bee-logo'

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-border/60">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-6 px-4 py-10 md:flex-row md:justify-between">
        <div className="flex items-center gap-2.5">
          <BeeLogo className="size-7" />
          <div>
            <p className="font-serif text-sm font-bold">
              Bee<span className="text-primary">Values</span>
            </p>
            <p className="text-xs text-muted-foreground">
              Улей ценностей Roblox Jailbreak
            </p>
          </div>
        </div>
        <nav className="flex items-center gap-5 text-sm text-muted-foreground" aria-label="Футер">
          <Link href="/values" className="hover:text-primary transition-colors">
            Values
          </Link>
          <Link href="/inventory" className="hover:text-primary transition-colors">
            Inventory
          </Link>
          <Link href="/calculator" className="hover:text-primary transition-colors">
            Calculator
          </Link>
        </nav>
        <p className="text-xs text-muted-foreground">
          Данные: Jailbreak Changelogs API. Не аффилировано с Badimo.
        </p>
      </div>
    </footer>
  )
}
