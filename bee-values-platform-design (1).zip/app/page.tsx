import Link from 'next/link'
import { ArrowRight, Calculator, PackageSearch, Sparkles } from 'lucide-react'
import { fetchItems } from '@/lib/api'
import { CATEGORIES, formatValue, parseValue, trendDirection } from '@/lib/items'
import { BeeLogo } from '@/components/bee-logo'
import { HomeShowcase } from '@/components/home-showcase'

export default async function HomePage() {
  let stats = {
    items: 945,
    categories: CATEGORIES.length,
    limited: 0,
    trades: 0,
  }
  let showcase: Awaited<ReturnType<typeof fetchItems>> = []

  try {
    const items = await fetchItems()
    stats = {
      items: items.length,
      categories: CATEGORIES.length,
      limited: items.filter((i) => i.is_limited === 1).length,
      trades: items.reduce((s, i) => s + (i.metadata?.TimesTraded ?? 0), 0),
    }
    showcase = [...items]
      .filter((i) => trendDirection(i.trend) === 'up' || parseValue(i.cash_value) >= 5_000_000)
      .sort((a, b) => parseValue(b.cash_value) - parseValue(a.cash_value))
      .slice(0, 8)
  } catch {
    // API unreachable — render with defaults
  }

  return (
    <div className="hex-pattern">
      {/* Hero */}
      <section className="mx-auto max-w-6xl px-4 pb-20 pt-14 md:pb-28 md:pt-24">
        <div className="flex flex-col items-center text-center">
          <div className="bee-float mb-8">
            <BeeLogo animated className="size-24 md:size-32" />
          </div>
          <p className="glass mb-6 rounded-full px-4 py-1.5 text-xs font-medium tracking-wide text-primary">
            Платформа ценностей Roblox Jailbreak
          </p>
          <h1 className="max-w-3xl text-balance font-serif text-4xl font-bold leading-tight tracking-tight md:text-6xl">
            Собирай ценность, как пчёлы собирают{' '}
            <span className="text-honey-gradient">мёд</span>
          </h1>
          <p className="mt-6 max-w-xl text-pretty leading-relaxed text-muted-foreground md:text-lg">
            Актуальные цены на все предметы Jailbreak, проверка инвентаря любого
            игрока и честный калькулятор трейдов — всё в одном улье.
          </p>
          <div className="mt-10 flex flex-col gap-3 sm:flex-row">
            <Link
              href="/values"
              className="buzz-hover honey-glow inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-7 py-3.5 font-semibold text-primary-foreground transition-colors hover:bg-honey-bright"
            >
              Смотреть цены
              <ArrowRight className="size-4" aria-hidden="true" />
            </Link>
            <Link
              href="/calculator"
              className="glass glass-hover inline-flex items-center justify-center gap-2 rounded-xl px-7 py-3.5 font-semibold text-foreground"
            >
              <Calculator className="size-4 text-primary" aria-hidden="true" />
              Калькулятор трейда
            </Link>
          </div>
        </div>

        {/* Stats */}
        <dl className="mt-20 grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
          {[
            { label: 'Предметов отслеживается', value: String(stats.items) },
            { label: 'Категорий', value: String(stats.categories) },
            { label: 'Limited-предметов', value: String(stats.limited) },
            { label: 'Трейдов учтено', value: formatValue(stats.trades) },
          ].map((s) => (
            <div key={s.label} className="glass glass-hover flex flex-col rounded-2xl p-5 text-center md:p-6">
              <dd className="font-serif text-3xl font-bold text-primary md:text-4xl">
                {s.value}
              </dd>
              <dt className="mt-1 text-xs leading-snug text-muted-foreground md:text-sm">
                {s.label}
              </dt>
            </div>
          ))}
        </dl>
      </section>

      {/* Feature cards */}
      <section className="mx-auto max-w-6xl px-4 pb-20">
        <h2 className="mb-8 text-balance font-serif text-2xl font-bold md:text-3xl">
          Три инструмента улья
        </h2>
        <div className="grid gap-4 md:grid-cols-3">
          {[
            {
              href: '/values',
              icon: Sparkles,
              title: 'Values',
              text: 'Каталог всех предметов по категориям: цена, тренд и деманд каждого предмета — от машин до скинов оружия.',
            },
            {
              href: '/inventory',
              icon: PackageSearch,
              title: 'Inventory Checker',
              text: 'Введите ник или Roblox ID — получите полный инвентарь игрока с разбивкой по категориям и общим networth.',
            },
            {
              href: '/calculator',
              icon: Calculator,
              title: 'Trade Calculator',
              text: 'Соберите обе стороны трейда и мгновенно узнайте, выгодна ли сделка, — без ручных подсчётов.',
            },
          ].map((f) => (
            <Link
              key={f.href}
              href={f.href}
              className="glass glass-hover group flex flex-col gap-4 rounded-2xl p-6 md:p-7"
            >
              <div className="flex size-11 items-center justify-center rounded-xl bg-accent">
                <f.icon className="size-5 text-primary" aria-hidden="true" />
              </div>
              <h3 className="font-serif text-lg font-bold">{f.title}</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">{f.text}</p>
              <span className="mt-auto inline-flex items-center gap-1.5 text-sm font-medium text-primary">
                Открыть
                <ArrowRight
                  className="size-3.5 transition-transform group-hover:translate-x-1"
                  aria-hidden="true"
                />
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* Trending showcase */}
      {showcase.length > 0 && <HomeShowcase items={showcase} />}
    </div>
  )
}
