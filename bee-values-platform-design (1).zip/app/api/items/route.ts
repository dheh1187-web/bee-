import { NextResponse } from 'next/server'
import { fetchItems } from '@/lib/api'

export async function GET() {
  try {
    const items = await fetchItems()
    return NextResponse.json(items, {
      headers: {
        'Cache-Control': 'public, s-maxage=300, stale-while-revalidate=600',
      },
    })
  } catch {
    return NextResponse.json(
      { error: 'Не удалось загрузить предметы' },
      { status: 502 },
    )
  }
}
