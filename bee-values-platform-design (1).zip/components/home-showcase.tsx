'use client'

import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import type { JBItem } from '@/lib/items'
import { ItemCard } from './item-card'

export function HomeShowcase({ items }: { items: JBItem[] }) {
  return (
    <section className="mx-auto max-w-6xl px-4 pb-8">
      <div className="mb-8 flex items-end justify-between gap-4">
        <div>
          <h2 className="text-balance font-serif text-2xl font-bold md:text-3xl">
            Топ улья прямо сейчас
          </h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Самые ценные и растущие предметы по данным трейдов
          </p>
        </div>
        <Link
          href="/values"
          className="hidden shrink-0 items-center gap-1.5 text-sm font-medium text-primary hover:text-honey-bright md:inline-flex"
        >
          Все предметы
          <ArrowRight className="size-3.5" aria-hidden="true" />
        </Link>
      </div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:gap-4 lg:grid-cols-4">
        {items.map((item) => (
          <ItemCard key={item.id} item={item} />
        ))}
      </div>
      <div className="mt-6 text-center md:hidden">
        <Link
          href="/values"
          className="inline-flex items-center gap-1.5 text-sm font-medium text-primary"
        >
          Все предметы
          <ArrowRight className="size-3.5" aria-hidden="true" />
        </Link>
      </div>
    </section>
  )
}
