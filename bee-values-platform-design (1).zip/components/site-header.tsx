'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { useState } from 'react'
import { Menu, Search, X } from 'lucide-react'
import { BeeLogo } from './bee-logo'
import { cn } from '@/lib/utils'

const NAV = [
  { href: '/values', label: 'Values' },
  { href: '/inventory', label: 'Inventory' },
  { href: '/calculator', label: 'Calculator' },
]

export function SiteHeader() {
  const pathname = usePathname()
  const router = useRouter()
  const [mobileOpen, setMobileOpen] = useState(false)
  const [query, setQuery] = useState('')

  function submitSearch(e: React.FormEvent) {
    e.preventDefault()
    const q = query.trim()
    if (!q) return
    setMobileOpen(false)
    router.push(`/values?q=${encodeURIComponent(q)}`)
  }

  return (
    <header className="fixed inset-x-0 top-0 z-50 px-3 pt-3 md:px-6">
      <div className="glass mx-auto flex max-w-6xl items-center gap-3 rounded-2xl px-4 py-2.5 md:px-5">
        <Link
          href="/"
          className="buzz-hover flex shrink-0 items-center gap-2.5"
          onClick={() => setMobileOpen(false)}
        >
          <BeeLogo className="size-8" />
          <span className="font-serif text-lg font-bold tracking-tight">
            Bee<span className="text-primary">Values</span>
          </span>
        </Link>

        <nav className="ml-4 hidden items-center gap-1 md:flex" aria-label="Основная навигация">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'rounded-lg px-3.5 py-2 text-sm font-medium transition-colors',
                pathname.startsWith(item.href)
                  ? 'bg-accent text-accent-foreground'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground',
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <form onSubmit={submitSearch} className="ml-auto hidden md:block" role="search">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Поиск предмета…"
              className="w-48 rounded-xl border border-border bg-input py-2 pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground focus:w-64 focus:border-ring focus:outline-none transition-all"
              aria-label="Поиск предмета"
            />
          </div>
        </form>

        <button
          type="button"
          onClick={() => setMobileOpen((v) => !v)}
          className="ml-auto rounded-lg p-2 text-foreground hover:bg-muted md:hidden"
          aria-expanded={mobileOpen}
          aria-label={mobileOpen ? 'Закрыть меню' : 'Открыть меню'}
        >
          {mobileOpen ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>

      {mobileOpen && (
        <div className="glass-strong mx-auto mt-2 max-w-6xl rounded-2xl p-4 md:hidden animate-fade-up">
          <form onSubmit={submitSearch} role="search" className="relative mb-3">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Поиск предмета…"
              className="w-full rounded-xl border border-border bg-input py-2.5 pl-9 pr-3 text-sm placeholder:text-muted-foreground focus:border-ring focus:outline-none"
              aria-label="Поиск предмета"
            />
          </form>
          <nav className="flex flex-col gap-1" aria-label="Мобильная навигация">
            {NAV.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className={cn(
                  'rounded-lg px-3.5 py-2.5 text-sm font-medium transition-colors',
                  pathname.startsWith(item.href)
                    ? 'bg-accent text-accent-foreground'
                    : 'text-muted-foreground hover:bg-muted hover:text-foreground',
                )}
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  )
}
