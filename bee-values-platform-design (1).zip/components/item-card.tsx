'use client'

import { useState } from 'react'
import { Minus, TrendingDown, TrendingUp } from 'lucide-react'
import {
  categoryLabel,
  demandLabel,
  formatValue,
  itemImageUrl,
  parseValue,
  trendDirection,
  trendLabel,
  type JBItem,
} from '@/lib/items'
import { BeeLogo } from './bee-logo'
import { cn } from '@/lib/utils'

export function TrendBadge({ trend }: { trend: string | null }) {
  const dir = trendDirection(trend)
  const Icon = dir === 'up' ? TrendingUp : dir === 'down' ? TrendingDown : Minus
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[11px] font-medium',
        dir === 'up' && 'bg-success/15 text-success',
        dir === 'down' && 'bg-danger/15 text-danger',
        dir === 'flat' && 'bg-muted text-muted-foreground',
      )}
    >
      <Icon className="size-3" aria-hidden="true" />
      {trendLabel(trend)}
    </span>
  )
}

export function ItemImage({
  item,
  className,
}: {
  item: Pick<JBItem, 'name' | 'type'>
  className?: string
}) {
  const [failed, setFailed] = useState(false)
  if (failed) {
    return (
      <div className={cn('flex items-center justify-center', className)}>
        <BeeLogo className="size-10 opacity-30" />
      </div>
    )
  }
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={itemImageUrl(item) || '/placeholder.svg'}
      alt={item.name}
      loading="lazy"
      onError={() => setFailed(true)}
      className={cn('object-contain', className)}
    />
  )
}

export function ItemCard({
  item,
  onClick,
  compact = false,
}: {
  item: JBItem
  onClick?: () => void
  compact?: boolean
}) {
  const value = parseValue(item.cash_value)
  const Wrapper = onClick ? 'button' : 'div'

  return (
    <Wrapper
      onClick={onClick}
      type={onClick ? 'button' : undefined}
      className={cn(
        'glass glass-hover group relative flex w-full flex-col overflow-hidden rounded-2xl text-left',
        onClick && 'cursor-pointer',
      )}
    >
      <div className="relative flex h-28 items-center justify-center bg-white/2 p-3 md:h-32">
        <ItemImage item={item} className="max-h-full max-w-full transition-transform duration-300 group-hover:scale-105" />
        {item.is_limited === 1 && (
          <span className="absolute left-2 top-2 rounded-md bg-primary/90 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-primary-foreground">
            Limited
          </span>
        )}
        {item.is_seasonal === 1 && (
          <span className="absolute right-2 top-2 rounded-md bg-bronze/80 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-honey-bright">
            Seasonal
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col gap-2 p-3.5">
        <div>
          <p className="truncate text-sm font-semibold leading-tight">{item.name}</p>
          <p className="text-xs text-muted-foreground">{categoryLabel(item.type)}</p>
        </div>
        <div className="mt-auto flex items-end justify-between gap-2">
          <div>
            <p className="text-[11px] uppercase tracking-wide text-muted-foreground">Value</p>
            <p className="font-serif text-base font-bold text-primary">
              {formatValue(value)}
            </p>
          </div>
          {!compact && <TrendBadge trend={item.trend} />}
        </div>
        {!compact && (
          <p className="text-[11px] text-muted-foreground">
            Деманд: <span className="text-foreground/80">{demandLabel(item.demand)}</span>
          </p>
        )}
      </div>
    </Wrapper>
  )
}
