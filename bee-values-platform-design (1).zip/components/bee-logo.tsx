import { cn } from '@/lib/utils'

/**
 * BeeValues brand mark — geometric bee inside a hexagon (honeycomb cell).
 * Original design: hex outline + abstract bee built from rounded segments.
 */
export function BeeLogo({
  className,
  animated = false,
}: {
  className?: string
  animated?: boolean
}) {
  return (
    <svg
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={cn('size-9', className)}
      aria-hidden="true"
    >
      {/* Hexagon cell */}
      <path
        d="M32 3 L57 17.5 V46.5 L32 61 L7 46.5 V17.5 Z"
        stroke="var(--honey)"
        strokeWidth="2.5"
        strokeLinejoin="round"
        fill="rgba(232,169,52,0.06)"
      />
      {/* Wings */}
      <g className={animated ? 'bee-wing' : undefined}>
        <ellipse
          cx="24"
          cy="22.5"
          rx="7"
          ry="4.5"
          transform="rotate(-32 24 22.5)"
          fill="rgba(240,192,96,0.35)"
          stroke="var(--honey-bright)"
          strokeWidth="1.4"
        />
        <ellipse
          cx="40"
          cy="22.5"
          rx="7"
          ry="4.5"
          transform="rotate(32 40 22.5)"
          fill="rgba(240,192,96,0.35)"
          stroke="var(--honey-bright)"
          strokeWidth="1.4"
        />
      </g>
      {/* Body — stacked rounded stripes */}
      <rect x="24" y="26" width="16" height="5.4" rx="2.7" fill="var(--honey)" />
      <rect x="23" y="33" width="18" height="5.4" rx="2.7" fill="var(--bronze)" />
      <rect x="25" y="40" width="14" height="5.4" rx="2.7" fill="var(--honey)" />
      {/* Stinger */}
      <path d="M32 47 L32 52.5" stroke="var(--honey-deep)" strokeWidth="2.2" strokeLinecap="round" />
      {/* Antennae */}
      <path
        d="M28.5 25 C27 21.5 25 20 22.5 19 M35.5 25 C37 21.5 39 20 41.5 19"
        stroke="var(--honey-bright)"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
      <circle cx="22.5" cy="19" r="1.5" fill="var(--honey-bright)" />
      <circle cx="41.5" cy="19" r="1.5" fill="var(--honey-bright)" />
    </svg>
  )
}
