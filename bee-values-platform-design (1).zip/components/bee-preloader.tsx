'use client'

import { useEffect, useState } from 'react'
import { BeeLogo } from './bee-logo'

/**
 * Fullscreen preloader: a bee orbits the BeeValues hex mark,
 * then the whole overlay fades away.
 */
export function BeePreloader() {
  const [gone, setGone] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => setGone(true), 2200)
    return () => clearTimeout(t)
  }, [])

  if (gone) return null

  return (
    <div
      className="preloader fixed inset-0 z-100 flex items-center justify-center bg-background"
      aria-hidden="true"
    >
      <div className="relative flex size-40 items-center justify-center">
        <BeeLogo className="size-16 opacity-90" />
        {/* Orbiting mini-bee */}
        <div className="preloader-bee absolute left-1/2 top-1/2 -ml-3 -mt-3">
          <svg viewBox="0 0 24 24" className="size-6" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g className="bee-wing">
              <ellipse cx="9" cy="7" rx="3.4" ry="2" transform="rotate(-30 9 7)" fill="rgba(240,192,96,0.5)" />
              <ellipse cx="15" cy="7" rx="3.4" ry="2" transform="rotate(30 15 7)" fill="rgba(240,192,96,0.5)" />
            </g>
            <rect x="8" y="9" width="8" height="3" rx="1.5" fill="var(--honey)" />
            <rect x="7.5" y="12.6" width="9" height="3" rx="1.5" fill="var(--bronze)" />
            <rect x="8.5" y="16.2" width="7" height="3" rx="1.5" fill="var(--honey)" />
          </svg>
        </div>
      </div>
      <p className="absolute bottom-[38%] font-serif text-sm tracking-[0.3em] text-muted-foreground uppercase">
        BeeValues
      </p>
    </div>
  )
}
